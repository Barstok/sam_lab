#!/bin/bash
dotnet MyWebApp.dll --urls "http://0.0.0.0:4080"